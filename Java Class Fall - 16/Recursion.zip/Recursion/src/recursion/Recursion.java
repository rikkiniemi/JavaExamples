/*
Rikki Niemi
CSC 18A Recursion Homework 5
 */
package recursion;

import java.util.Scanner;


public class Recursion {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
                            
        //Variables for exponent
        int pow=0, base=0, initial=0, GCD=0, a=0, b=0, a1=0, b1=0,swap=0;    
            
        //Read in varibles for exponent
        System.out.println("Enter the base ");
        base=input.nextInt();
        
        //Save initial base value
        initial = base;
        
        int exprslt=1;
        
        System.out.println("Enter the exponent ");
        
        pow=input.nextInt();
       
        //Print result for base to the 0 power
        switch (pow){
        case 0: System.out.println(base+ " ^ 0 = 1"  );
            break;
         }

        //Loop to calculate exponent
        for(int i=1; i <= pow; i++){
                  
        exprslt = integerPower ( pow, base );
        
        }
        System.out.println(base+ " ^ " +pow+ " = " +exprslt );

        
        
/**************************************************************************
 *************************** GCD ******************************************/
        
        
        //Read in varibles for GCD
        System.out.println("Enter a number ");
        a = input.nextInt(); 
        a1=a;

        System.out.println("Enter another number ");
        b = input.nextInt();
        b1=b;
        
        //Swap values if divisor is greater than number to be divided
        if( a < b ){
            
            swap = a;
            
            a = b;
            
            b = swap;  
            
            a1=a;
            b1=b;
            
        }

        //Print result
        System.out.printf("%d%s%d%s%d%n",a1," and ",b1 ," have a GCD of ",gcd(a, b));

        
    }
    
    
/*******************************************************
*******Exponent Calculator Function*********************/
public static int integerPower( int pow, int base ){
    //Test base case
    switch (pow){
        case 0: return 1;
        case 1: return base;
    }

    return base*integerPower( pow -1 , base ); 
}

/*****************************************************
*****************GCD Function************************/

public static int  gcd(int a, int b){
    //Test base case
    if( b == 0){
        return a;
    }
 
        return gcd( b, a%b );
    }
    
}
