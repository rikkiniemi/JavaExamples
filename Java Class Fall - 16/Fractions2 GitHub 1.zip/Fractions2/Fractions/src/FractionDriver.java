public class FractionDriver {

    public static void main(String[] args) {
        Fraction a = new Fraction();        
        Fraction b = new Fraction(1,3);
        
        System.out.println(a.toString());
        System.out.println(b.toString());
        
        
        System.out.println(a.add(b));

    }
    
}
