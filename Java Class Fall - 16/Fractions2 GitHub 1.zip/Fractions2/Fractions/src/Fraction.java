
/**********************************************************************************
 * Rikki's Revisions
 * 
 * Throughout this code I will add big block comments where I can indicate what I changed,
 * with a short explanation of why I made that change, not only for myself, but so that you
 * can understand, too.
 * 
 * *******************************************************************************/


public class Fraction {

    // member variables (attributes, properties)
    private int numerator;
    private int denominator;
    
    // constructors
    public Fraction()
    {
        numerator=5;
        denominator=3;
    }
    
    public Fraction(int n, int d)
    {
        setNumerator(n);
        setDenominator(d);
        reduce();
    }
    
    // copy constructor
    public Fraction(Fraction source)
    {
        numerator=source.getNumerator();
        denominator=source.getDenominator();
    }
    
    // get/set methods for numerator and denominator
    public int getNumerator()
    {
        return numerator;
    }
    
    public void setNumerator(int newNumerator)
    {
        numerator=newNumerator;
        //reduce();
    }
    
    public int getDenominator()
    {
        return denominator;
    }
    
    public void setDenominator(int newDenominator)
    {
        if ( newDenominator==0 ) throw new IllegalArgumentException();
        if ( newDenominator<0 )
        {
            numerator = -numerator;
            denominator = -newDenominator;
            //reduce();
        }
        else {
            denominator=newDenominator;
            //reduce();
        }
    }
    
    // utility methods
    private static int gcd(int n, int d)
    {
        int a=n, b=d;
        while ( b != 0 )
        {
            int r = a % b;
            a=b;
            b=r;
        }
        return a;
    }
    
    private void reduce()
    {
        // reduces our fraction to reduced form if possible
        int _gcd=gcd(numerator,denominator); // find the gcd
        if ( _gcd!=0 )
        {
            numerator /= _gcd;
            denominator /= _gcd;
        }
    }
    
    // return decimal value of our fraction
    public double value()
    {
        return numerator / (double)denominator;
    }
    
    public boolean equals(Fraction f2)
    {
        return ( numerator==f2.getNumerator() && denominator==f2.getDenominator() );
    }
    
    @Override
    public String toString()
    {
        return numerator+" / "+denominator;
    }
    
    public Fraction add(Fraction f2)
    {
         /**********************************************************************************
         * These two following variables are the values of the Fraction 'a' (in the driver) object's
         * numerator and denominator
         * *******************************************************************************/
        int a = numerator;                  // numerator of our fraction object
        int b = denominator;                // denominator of our fraction object
        
        
         /**********************************************************************************
         * These two following variables are the values of the Fraction 'b' (in the driver) object's
         * numerator and denominator.
         * *******************************************************************************/
        int c = f2.getNumerator();          // numerator of f2 argument
        int d = f2.getDenominator();        // denominator of f2 argument
       
        /*************************************************************************************************************
         * I think I can comment out the creation of a new fraction below in the 'if' statement, as well as the 'gcd' 
         * since we will call the static 'add' method upon return, which already does the same things
         * ***********************************************************************************************************/
        
        //if ( b==d )
        //{
            
            //return new Fraction( a+c, b );
        //}
        
        //int _gcd = gcd(a*d+b*c,b*d);
        

         /*******************************************************************************************
         * The 'add' Method only takes in 2 parameters that are Fraction objects. Because of this,
         * we must create a fraction object so we can pass in the proper amount of parameters, as well
         * as the proper type to be able to call it and use it upon return.
         * 
         * The fraction object below is created using the parameters 'a' and 'b', which represent the 
         * numerator and denominator, respectively, that are specified in the Fraction() method 
         * (Line 19). This can be thought of as the Fraction 'a' object in the driver.
         * 
         * Also, we don't need to create another object to represent the fraction object 'b' in the 
         * driver because it has already been done. Fraction object 'b' is the parameter for this 
         * method, and if you look above to line 112, it can be seen that 'b' is the 'f2' argument.  
         *******************************************************************************************/
        
         Fraction f1 = new Fraction(a,b);
                                                            
        /**********************************************************************************************
         * Call the add method, and pass in Fraction object f1, which represents Fraction object 'a' 
         * in the driver, and fraction object 'f2', which represents fraction object 'b' in the driver.
         ***********************************************************************************************************************************/
         return add(f1,f2);
    }
    
    public Fraction subtract(Fraction f2)
    {
        int a = numerator;              // numerator of our fraction object
        int b = denominator;            // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
        
        //Comment out because this is done in the non-static method that will be called on return
        //if ( b==d )
        //{
        //    return new Fraction( a-c, b );
        //}
        
        //Create new fraction object to represent fraction object 'a' in the driver
        Fraction f1= new Fraction(a,b);
        
        /************************************************************************************************
         * Call subtract method, and pass in f1 and f2 fraction objects, which represent fraction objects 
         * 'a' and 'b' in the driver, respectively.
         ***********************************************************************************************/
        return subtract( f1,f2 );
    }
    
    public Fraction multiply(Fraction f2)
    {
        int a = numerator;              // numerator of our fraction object
        int b = denominator;            // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
        
        //Create new fraction object to represent fraction object 'a' in the driver
        Fraction f1 = new Fraction( a,b);
        
         /************************************************************************************************
         * Call multiply method, and pass in f1 and f2 fraction objects, which represent fraction objects 
         * 'a' and 'b' in the driver, respectively.
         ***********************************************************************************************/
        return multiply(f1, f2);
        
    }
    
    public Fraction divide(Fraction f2)
    {
        int a = numerator;              // numerator of our fraction object
        int b = denominator;            // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
       
        //Create new fraction object to represent fraction object 'a' in the driver
        Fraction f1= new Fraction( a,b);
        
        /************************************************************************************************
         * Call divide method, and pass in f1 and f2 fraction objects, which represent fraction objects 
         * 'a' and 'b' in the driver, respectively.
         ***********************************************************************************************/
        return divide( f1, f2 );
    }
   
    
    
    
    /****************************************************************************************************
     * These are all of that static methods that will be called, so I left these alone.
     ***************************************************************************************************/
    
    // implementation of static methods for add, subtract, multiply and divide
    public static Fraction add(Fraction f1, Fraction f2)
    {
        int a = f1.getNumerator();      // numerator of our fraction object
        int b = f1.getDenominator();    // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
        
        if ( b==d )
        {
            return new Fraction( a+c, b );
        }
        int _gcd = gcd(a*d+b*c,b*d);
        return new Fraction( (a*d+b*c)/_gcd, (b*d)/_gcd );
    }
    
    public static Fraction subtract(Fraction f1, Fraction f2)
    {
        int a = f1.getNumerator();      // numerator of our fraction object
        int b = f1.getDenominator();    // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
        
        if ( b==d )
        {
            return new Fraction( a-c, b );
        }
        
        return new Fraction( a*d-b*c, b*d );
    }
    
    public static Fraction multiply(Fraction f1, Fraction f2)
    {
        int a = f1.getNumerator();      // numerator of our fraction object
        int b = f1.getDenominator();    // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
        
        return new Fraction( a*c, b*d );
    }
    
    public static Fraction divide(Fraction f1, Fraction f2)
    {
        int a = f1.getNumerator();      // numerator of our fraction object
        int b = f1.getDenominator();    // denominator of our fraction object
        int c = f2.getNumerator();      // numerator of f2 argument
        int d = f2.getDenominator();    // denominator of f2 argument
        
        return new Fraction( a*d, b*c );
    }
}
